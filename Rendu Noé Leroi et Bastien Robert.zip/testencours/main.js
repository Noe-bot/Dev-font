Vue.component('film-list', {
    props: ['films'],
    template: `
    <div>
        <div v-for="(f, index) in films" v-if="index%2==0">
            <div class="anotherflexbitesthedust">
                <div class="flexingfromhighrank" >
                    <h2 class ="articlestitre">{{f.titre}}</h2>
                    <img v-bind:src="f.image"></img>
                    <p class="para">
                        {{f.desc}}
                    </p>
                </div>

            <span class="ligne" v-if="index+1<films.length"></span>

                <div class="flexingfromhighrank"  v-if="index+1<films.length">
                    <h2 class ="articlestitre">{{films[index+1].titre}}</h2>
                    <img v-bind:src="films[index+1].image"></img>
                    <p class="para">
                    {{films[index+1].desc}}
                    </p>
                </div>
            </div>
        </div>
    </div>
    `
});





var app = new Vue({
    el: '#app',
    data: {

        titre:'',
        image:'',
        desc:'',

        films: [
            { 
                id: 1,
                image: 'joker.jpg', 
                titre: 'Le petit blagueur lol',
                desc: 'omaewa mou shindeiru',
            },
            {
                id: 2,
                image: 'joker.jpg', 
                titre: 'Le farceur sympathique',
                desc: 'Nani',
            },
            {
                id: 3,
                image: 'joker.jpg', 
                titre: 'Le faOUIpathique',
                desc: 'Nani',
            },
            {
                id: 4,
                image: 'joker.jpg', 
                titre: 'Le xdddddd',
                desc: 'Nani',
            }

        ],

        moviesVisible: true,
    },
    methods: {
        clickLogin : function() {
            this.moviesVisible = false;
        },
        clickHome : function() {
            this.moviesVisible = true;
        },
        addMovie : function(){
            
            var titleu = this.titre;
            var imageu = this.image;
            var desceu = this.desc;
            this.films.push({image:imageu,titre:titleu,desc:desceu});



        }
    } //ce travail a été réalisé en collaboration partielle avec monseigneur LEGUYADER Olivier
})